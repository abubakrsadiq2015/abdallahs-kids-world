const questions = [
  {
    q: "What does Tajweed help us do?",
    a: ["Read the Quran correctly", "Play basketball", "Build a robot", "Cook food"],
    correct: 0
  },
  {
    q: "Which one is a branch of science?",
    a: ["Biology", "Football", "Volleyball", "Painting"],
    correct: 0
  },
  {
    q: "Which machine can be programmed to do tasks?",
    a: ["Robot", "Book", "Ball", "Chair"],
    correct: 0
  },
  {
    q: "How many players are on the court for one basketball team during play?",
    a: ["5", "7", "9", "11"],
    correct: 0
  }
];

let current = 0;
let score = 0;

function loadQuestion() {
  const item = questions[current];
  document.getElementById("question").textContent = `${current + 1}. ${item.q}`;
  const answers = document.getElementById("answers");
  answers.innerHTML = "";
  item.a.forEach((answer, index) => {
    const btn = document.createElement("button");
    btn.textContent = answer;
    btn.className = "answer";
    btn.onclick = () => chooseAnswer(index, btn);
    answers.appendChild(btn);
  });
  document.getElementById("nextBtn").classList.add("hidden");
  document.getElementById("score").textContent = "";
}

function chooseAnswer(index, clicked) {
  const buttons = document.querySelectorAll(".answer");
  buttons.forEach(b => b.disabled = true);

  if (index === questions[current].correct) {
    score++;
    clicked.classList.add("correct");
  } else {
    clicked.classList.add("wrong");
    buttons[questions[current].correct].classList.add("correct");
  }
  document.getElementById("nextBtn").classList.remove("hidden");
}

function nextQuestion() {
  current++;
  if (current < questions.length) {
    loadQuestion();
  } else {
    document.getElementById("question").textContent = "🎉 Quiz complete!";
    document.getElementById("answers").innerHTML = "";
    document.getElementById("nextBtn").classList.add("hidden");
    document.getElementById("score").textContent =
      `Your score: ${score} / ${questions.length}`;
    const restart = document.createElement("button");
    restart.textContent = "Play Again";
    restart.onclick = () => {
      current = 0; score = 0; loadQuestion();
    };
    document.getElementById("answers").appendChild(restart);
  }
}

function showMessage(text) {
  const box = document.getElementById("message");
  box.textContent = text;
  box.classList.add("show");
  setTimeout(() => box.classList.remove("show"), 2500);
}

loadQuestion();
